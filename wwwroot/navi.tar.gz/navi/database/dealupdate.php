<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
$id=$_POST['id'];
$deal =$_POST['deal'];
echo '|'.$id.'|'.$deal;
$conn = mysqli_connect('localhost', 'root', '541550872', "dataDB");
// 检测连接
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	$sql= "UPDATE imageDB SET deal='$deal' WHERE ID='$id'";
// 创建连接
if (mysqli_query($conn, $sql)) {
  echo 1;
} else {
   echo 0;
}
mysqli_close($conn);
?>