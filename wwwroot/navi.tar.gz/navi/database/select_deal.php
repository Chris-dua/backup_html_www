<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
$conn = new mysqli('localhost', 'root', '541550872', "dataDB");
$sql= "SELECT deal,COUNT(*) as repetitions,deal FROM imageDB GROUP BY deal HAVING repetitions > 0";
// 创建连接
$result = $conn->query($sql);
  if ($result->num_rows) {
      while($row = $result->fetch_assoc()) {
    	if($row['deal']=='0'){
      		$deal="未处理";
      	}elseif($row['deal']=='1'){
      		$deal="已处理";
      	}
      	$paper_post = 
		'
		<option>'.$deal.'</option>
		';
		array_push($row,  $paper_post);
        $paper_result[] = $row;
      }
  } else {
      echo "0 结果";
  }
  echo json_encode($paper_result);
?>