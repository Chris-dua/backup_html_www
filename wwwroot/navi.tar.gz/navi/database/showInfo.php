<?php
//跨域问题
  header("Access-Control-Allow-Origin:*");
  header('Access-Control-Allow-Methods:POST');
  header('Access-Control-Allow-Headers:x-requested-with, content-type');

  header("Content-type:application/json");
  require_once("config.php");
  $dbname = "dataDB";
  $length=$_POST['length'];
  $conn = new mysqli($servername, $username, $password,$dbname);
  $sql = "select ID,name,time,tag,base64,gps,addr,deal from imageDB order by time desc limit ".$length."";
  $result = $conn->query($sql);
  if ($result->num_rows) {
      $paper_result = array();
      // 输出数据
      while($row = $result->fetch_assoc()) {
      	if($row['deal']=='0'){
      		$deal="未处理";
      	}elseif($row['deal']=='1'){
      		$deal="已处理";
      	}
		$paper_post = 
		'
    <div class="panel panel-default" >
        <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse'.$row['ID'].'" style="text-decoration:none">
                <div class="col-md-2">
                <span class="post-title label label-info">
                	'. $row["tag"].'
                </span>
                <button onClick="deal(this)" id="'.$row['ID'].','.$row['deal'].'">'.$deal.'</button>
                 <span>'.$row['time'].'</span>
                 </div>
                <div class="col-md-10">
                 <table >
	          <tr width="274">
	          <td width="74" style="text-align:center"><h2 class="post-title panel-title" style="margin-left:1%">'.$row['name'].'</h2></td>

			<td width="250" style="text-align:center"><span class="pv" id="GPS'.$row['ID'].'">'.$row['addr'].'</span></td>
			<td  id="'.$row['gps'].'" onClick="goTo(this)">查看地图</td>
			<td ><button id="'.$row['time'].'/'.$row['name'].'" onClick="Delete(this)">删除</button></td>
				<tr>
				</table>
				</table>
                </a>
            </h4>
        </div>
        <div id="collapse'.$row['ID'].'" class="panel-collapse collapse">
            <div class="panel-body">
				<img src="'.$row['base64'].'">
            </div>
            <div class="meta" style="bottom: 0;" >
	         
				</div>
				</div>
				</div>';
		array_push($row,  $paper_post);
        $paper_result[] = $row;
      }
  } else {
      echo "0 结果";
  }
  $conn->close();
  $sql="select count(*) from imageDB";
  $conn = new mysqli($servername, $username, $password,$dbname);
  $result = $conn->query($sql);
  if ($result->num_rows) {
    while($row = $result->fetch_assoc()) {
        $paper_result[] = $row;
      }
	}
  echo json_encode($paper_result);
 ?>
