<?php

header("Content-type:application/json");
//获取数据库配置
require_once("config.php");
function SearchImg($name){
	$conn = new mysqli('localhost', 'root', '541550872','dataDB');
	// Check connection
	if ($conn->connect_error) {
	    die("连接失败: " . $conn->connect_error);
	} 
	 
	$sql = "SELECT name FROM imageDB where name='".$name."'";
	$result = $conn->query($sql);
	 
	if ($result->num_rows > 0) {
		return 1;
	} else {
	   return 0;
	}
	$conn->close(); 
}
?>