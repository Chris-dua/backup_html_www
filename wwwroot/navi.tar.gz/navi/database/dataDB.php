<?php 
  require_once("config.php");
  // 创建连接
  $conn = new mysqli('localhost', 'root', '541550872');
  $sql = "CREATE DATABASE IF NOT EXISTS dataDB";
  $dbname = "imageDB";
  if ($conn->query($sql) === TRUE) {
  } else {
      echo "Error creating database: " . $conn->error;
  }
  $sql = "CREATE TABLE IF NOT EXISTS ".$dbname."(
    ID INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(1000) NOT NULL,
    time VARCHAR(50) NOT NULL,
    tag  VARCHAR(1000) NOT NULL,
    base64   TEXT(50000) NOT NULL,
    gps VARCHAR(50) NOT NULL,
    addr VARCHAR(50) NOT NULL,
    deal  VARCHAR(50) NOT NULL
  );";
  $conn = new mysqli($servername, $username, $password, $db);
  mysqli_query($conn , "SET NAMES UTF8");
  mysqli_query($conn ,"SET CHARACTER SET UTF8");
  mysqli_query($conn ,"SET CHARACTER_SET_RESULTS=UTF8'");
  if ($conn->query($sql) === TRUE) {
  } else {
      echo "创建数据表错误: " . $conn->error;
  }
?>