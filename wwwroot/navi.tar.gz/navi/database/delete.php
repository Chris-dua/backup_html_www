<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
$img_dir = "/www/wwwroot/navi/pathimg/";
$img_finaldir = "../finalimg/";
$time=$_POST['time'];
$name=$_POST['name'];
$conn = mysqli_connect('localhost', 'root', '541550872', "dataDB");
// 检测连接
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	$sql= "DELETE FROM imageDB WHERE name='$name'";
// 创建连接
if (mysqli_query($conn, $sql)) {
	echo $img_dir.$time.'/'.$name;
  unlink($img_dir.$time.'/'.$name);
  unlink($img_finaldir.$time.'/'.$name);
  echo $id.$addr;

} else {
   echo 0;
}
mysqli_close($conn);
?>