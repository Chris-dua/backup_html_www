<?php
$servername="localhost";
$username="root";
$password="541550872";
$db="dataDB";
?>