<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
$conn = new mysqli('localhost', 'root', '541550872', "dataDB");
$sql= "select count(*) as value from imageDB";
// 创建连接
$result = $conn->query($sql);
  if ($result->num_rows) {
      while($row = $result->fetch_assoc()) {
        $paper_result[] = $row;
      }
  } else {
      echo "0 结果";
  }
  echo json_encode($paper_result);
?>