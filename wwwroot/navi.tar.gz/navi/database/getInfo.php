<?php
//跨域问题
  header("Access-Control-Allow-Origin:*");
  header('Access-Control-Allow-Methods:POST');
  header('Access-Control-Allow-Headers:x-requested-with, content-type');

  header("Content-type:application/json");
  require_once("config.php");
  $dbname = "dataDB";
  $conn = new mysqli($servername, $username, $password,$dbname);
  $sql = "select name,time,tag,base64,gps,addr,deal from imageDB order by time desc";
  $result = $conn->query($sql);
  $i = 0;
  if ($result->num_rows) {
      $paper_result = array();
      // 输出数据
      while($row = $result->fetch_assoc()) {
		$paper_result['name'][$i] = $row['name'];
		$paper_result['time'][$i] = $row['time'];
		$paper_result['tag'][$i] = $row['tag'];
		$paper_result['base64'][$i] = $row['base64'];
		$paper_result['gps'][$i] = $row['gps'];
		$paper_result['deal'][$i] = $row['deal'];
		$paper_result['addr'][$i] = $row['addr'];
		$i++;
      }
  } else {
      echo "0 结果";
  }
  echo json_encode($paper_result);
 ?>
