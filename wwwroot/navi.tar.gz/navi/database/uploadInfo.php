<?php
function ImgInfoAdd($name,$time,$tag,$base64,$gps){
	require_once("config.php");
$conn = mysqli_connect('localhost', 'root', '541550872', "dataDB");
// 检测连接
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	$sql= "INSERT INTO imageDB (name,time,tag,base64,gps,deal)
	VALUES ('$name','$time', '$tag','$base64','$gps', '0') ";
// 创建连接
if (mysqli_query($conn, $sql)) {
  echo "新记录插入成功";
} else {
   echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
}
?>