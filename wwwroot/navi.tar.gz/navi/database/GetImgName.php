<?php
//phpinfo();
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:image/jpeg");
require_once('dataDB.php');
require_once('search.php');
require_once('uploadInfo.php');

$i = 0;
$j = 0;
$img;
$img_dir = "/www/wwwroot/navi/pathimg";
  //测试示例

$img = getFileNames($img_dir);
echo var_dump($img);
//echo count($img['dir']);
for($k=0;$k<count($img['dir']);$k++){
	//var_dump($file_arr);
	for($g=0;$g<count((array)$img[$k]);$g++){
	    if(!SearchImg($img[$k][$g])){
			ImgInfo($k,$g);
    	}
	}

}
header("Content-Type:text/html;charset=utf-8");//解决不执行js的问题
echo '<script>';
//echo'location.href="http://49.235.199.48/dataShow.php";';
echo'</script>'; 

function funcadd(){
	global $j;
	return $j++;
}	
 function getFileNames($dir){
 	global $i,$j,$img;
     //检查是否为目录
      if(is_dir($dir)){
          //打开一个目录句柄
          if ($dh = opendir($dir)){
               
              //判断打开的目录句柄中的条目
              while (($file = readdir($dh)) !== false){
                  //判断是否为目录，进入子目录读取
                  if((is_dir($dir."/".$file)) && $file!="." && $file!=".."){
                      //echo "<b><font color='red'>文件夹名：</font></b>",$file,"<hr>";
                      $i++;
                      $j=0;
                      $img['dir'][$i-1] = $file;
                      getFileNames($dir."/".$file."/");
                  }else{
                      if($file!="." && $file!=".."){
                      //echo $file."";
          			  funcadd();
                      $img[$i-1][$j-1] = $file;
                      }
                  }
              }
              closedir($dh);
          }
      }
	return $img;
  }

 function ImgInfo($k,$g){
	  global $img;
	  $img_path = '/www/wwwroot/navi/pathimg'.'/'.$img["dir"][$k].'/'.$img[$k][$g];
   	  $file_arr = exif_read_data($img_path);
   	  //var_dump($file_arr);
	  $L = dataConvert($file_arr['GPSLatitude']);
	  $G =  dataConvert($file_arr['GPSLongitude']);
	  $gps = $G.','.$L;
	  $tag = "default";
	  $base64 = '';
	  if(is_dir( '/www/wwwroot/navi/finalimg'.'/'.$img["dir"][$k]))
		{
		   if(file_exists('/www/wwwroot/navi/finalimg'.'/'.$img["dir"][$k].'/'.$img[$k][$g])){
	   		  $base64 = imgToBase64('../finalimg/'.$img["dir"][$k].'/'.$img[$k][$g]);
	   		  ImgInfoAdd($img[$k][$g],$img["dir"][$k],$tag,$base64,$gps);
		   }else{
		   	  imagepress($img_path,$img["dir"][$k],$img[$k][$g]);
		   	  ImgInfo($k,$g);
		   }
		}else{
			mkdir ('/www/wwwroot/navi/finalimg'.'/'.$img["dir"][$k],0777,true);
			ImgInfo($k,$g);
		}
 }
 
function dataConvert($arr){
	for($i=0;$i<3;$i++){
		$arr[$i] = number_format($arr[$i]);
	}
	return round($arr[0] + $arr[1]/60 + $arr[2]/3600,15);
}
 function imgToBase64($img_file) {

    $img_base64 = '';
    if (file_exists($img_file)) {
		$width = 400;
		$height = 200;
        $app_img_file = $img_file; // 图片路径
        $img_info = getimagesize($app_img_file); // 取得图片的大小，类型等
		//var_dump($img_info);
        //echo '<pre>' . print_r($img_info, true) . '</pre><br>';
        $fp = fopen($img_file, "r"); // 图片是否可读权限

        if ($fp) {
            $filesize = filesize($img_file);
            $content = fread($fp, $filesize);
            $file_content = chunk_split(base64_encode($content)); // base64编码
            switch ($img_info[2]) {           //判读图片类型
                case 1: $img_type = "gif";
                    break;
                case 2: $img_type = "jpg";
                    break;
                case 3: $img_type = "png";
                    break;
            }
            $img_base64 = 'data:image/' . $img_type . ';base64,' . $file_content;//合成图片的base64编码
        }
        fclose($fp);
    }

    return $img_base64; //返回图片的base64
}

function imagepress($filepath,$path,$name){  
// 图片类型  
	header('Content-Type: image/jpeg');  
	// 获得新的图片大小  
	list($width, $height) = getimagesize($filepath);  
	$new_width = 320;  
	$new_height = 200;  
	// 重新取样  
	$image_p = imagecreatetruecolor($new_width, $new_height);  
	$image = imagecreatefromjpeg($filepath);  
	imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);  
	imagejpeg($image_p,'../finalimg/'.$path.'/'.$name); 
	ImageDestroy($image_p);

} 


  ?>