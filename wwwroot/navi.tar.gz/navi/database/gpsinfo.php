<?php
//跨域问题
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
  require_once("config.php");
  $gps=$_POST["gps"];
  $dbname = "dataDB";

  $conn = new mysqli($servername, $username, $password,$dbname);
  echo $gps;
  $sql = "select name,time,tag,base64,addr,deal from imageDB where gps='".$gps."'";
  echo $sql;
  $result = $conn->query($sql);
  $i = 0;
  if ($result->num_rows) {
      $paper_result = array();
      // 输出数据
      while($row = $result->fetch_assoc()) {
		$paper_result['name'] = $row['name'];
		$paper_result['time'] = $row['time'];
		$paper_result['tag'] = $row['tag'];
		$paper_result['base64'] = $row['base64'];
		$paper_result['deal'] = $row['deal'];
		$paper_result['addr'] = $row['addr'];
      }
  } else {
      echo "0 结果";
  }
  echo json_encode($paper_result);
 ?>
