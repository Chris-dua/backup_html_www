<?php
header("Access-Control-Allow-Origin:*");
header('Access-Control-Allow-Methods:POST');
header('Access-Control-Allow-Headers:x-requested-with, content-type');
header("Content-type:application/json");
$conn = new mysqli('localhost', 'root', '541550872', "dataDB");
$sql= "SELECT tag,COUNT(*) as repetitions,tag FROM imageDB GROUP BY tag HAVING repetitions > 0";
// 创建连接
$result = $conn->query($sql);
  if ($result->num_rows) {
      while($row = $result->fetch_assoc()) {
      	$paper_post = 
		'
		<option>'.$row['tag'].'</option>
		';
		array_push($row,  $paper_post);
        $paper_result[] = $row;
      }
  } else {
      echo "0 结果";
  }
  echo json_encode($paper_result);
?>