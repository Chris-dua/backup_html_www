$.post("../database/select_time.php", {
          },function(data){
            var con;
            for (var i=0;i<data.length;i++)
		      {
				 $("#time-info").append(data[i][0]);
		      }
  },"json");
 $.post("../database/select_tag.php", {
          },function(data){
            var con;
            for (var i=0;i<data.length;i++)
		      {
				 $("#tag-info").append(data[i][0]);
		      }
           
  },"json");
   $.post("../database/select_deal.php", {
          },function(data){
            var con;
            for (var i=0;i<data.length;i++)
		      {
				$("#deal-info").append(data[i][0]);
		      }
            
  },"json");
  
   function screen() {
	  var tag=select_info("tag-info");
			    var deal=select_info("deal-info");
			    var time=select_info("time-info");
		    
			    $("#data-show>.panel").each(function(){
					var tagStr = $(this).children().children().children().children().children()[0].innerHTML;
				    var dealStr = $(this).children().children().children().children().children()[1].innerHTML;
				    var timeStr = $(this).children().children().children().children().children()[2].innerHTML;
				    if((tag==tagStr)&&(deal==dealStr)&&(time==timeStr)){
			    		$(this).show();
				    }else if((tag=='default')&&(deal==dealStr)&&(time==timeStr)){
				    	$(this).show();
				    }else if((tag==tagStr)&&(deal=='default')&&(time==timeStr)){
				    	$(this).show();
				    }else if((tag==tagStr)&&(deal==dealStr)&&(time=='default')){
				    	$(this).show();
				    }else if((tag=='default')&&(deal=='default')&&(time==timeStr)){
				    	$(this).show();
				    }else if((tag=='default')&&(deal==dealStr)&&(time=='default')){
				    	$(this).show();
				    }else if((tag==tagStr)&&(deal=='default')&&(time=='default')){
				    	$(this).show();
				    }else if((tag=='default')&&(deal=='default')&&(time=='default')){
				    	location='dataShow.php';
				    }else{
				    	$(this).hide();
				    }
			}) 
	  	
}
function getAll(){
	   	   $.post("../database/row.php", {
          },function(data){
          		admin_dot(data[0].value);
          		setTimeout("screen()",1000);
	  },"json");
}

function select_info(id){
	var myselect=document.getElementById(id);
    var index=myselect.selectedIndex;
    var insertVal = myselect.options[index].innerHTML;
    return insertVal;
}