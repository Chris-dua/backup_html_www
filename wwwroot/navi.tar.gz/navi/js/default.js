//定义一些常量

var x_PI = 3.14159265358979324 * 3000.0 / 180.0;

var PI = 3.1415926535897932384626;

var a = 6378245.0;

var ee = 0.00669342162296594323;

function setpoint(){
	jQuery.post("http://49.234.131.127/database/getInfo.php", {
    }, function(data){
		info = data;
		var pointsArr = new Array();
		var gps_data = new Array();
		for(var i=0;i<info['gps'].length;i++){
			if(info['deal'][i]=='0'){
				console.log(info);
				gps_data = gpsSplit(info['gps'][i]);
				//pointsArr[i] = new BMap.Point(gps_data[0],gps_data[1]);
				//自定义函数转换
				 var gps = wgs84togcj02(gps_data[0], gps_data[1]);
				 
				 var opts = {
				   width : 330,     // 信息窗口宽度
				   height: 250,     // 信息窗口高度
				   title : "问题:"+info['tag'][i]+' '+'时间:'+info['time'][i] , // 信息窗口标题
				   enableMessage:true//设置允许信息窗发送短息
				 }
				 var infoWindow = new BMap.InfoWindow("<img src='"+info['base64'][i]+"'>"+"地点:"+info['addr'][i], opts);  // 创建信息窗口对象 
				 gps[2] = infoWindow;
				 gps_dot(gps);
				//pointsArr['info'][i] = info['gps'][i];
				//map_setpoint(gps[0],gps[1],info['gps'][i]);
			}
		}
		//map_setpoint(pointsArr);
     }, "json");
}

function goTo(obj){
	location="http://49.234.131.127/index.html?id="+obj.id;
}
function gpsSplit(arr){
 	arr = arr.split(",");
	for(var i=0;i<arr.length;i++){
		arr[i] = parseFloat(arr[i],15);
	}
 	return arr;
}

function gps_dot(point){
	var setpoint = new BMap.Point(point[0], point[1]);
	map.centerAndZoom(setpoint, 15);
	var marker = new BMap.Marker(setpoint);  // 创建标注
	map.addOverlay(marker);               // 将标注添加到地图中
	marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画

	marker.addEventListener("click", function(){          
		map.openInfoWindow(point[2],setpoint); //开启信息窗口
	});
}
function setCenter(gps){
	var gps = gpsSplit(gps);
	gps = wgs84togcj02(gps[0], gps[1]);
	gps_dot(gps);
}
function getQueryVariable(variable)
{
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}		
		
function map_setpoint(points){
	map.centerAndZoom(new BMap.Point(116.378688937,39.9076296510), 15);
    //坐标转换完之后的回调函数
    translateCallback = function (data){
      if(data.status === 0) {
        for (var i = 0; i < data.points.length; i++) {
        	var marker = new BMap.Marker(data.points[i]);
            map.addOverlay(marker);
            var str = "编号"+i+"坐标："+data.points[i].lng+","+data.points[i].lat;
            var label = new BMap.Label(str,{offset:new BMap.Size(20,-10)});
        	marker.setLabel(label); //添加百度label
            map.setCenter(data.points[i]);
        }
      }
    }
    setTimeout(function(){
		var convertor = new BMap.Convertor();
        convertor.translate(points, 1, 5, translateCallback)
    }, 1000);
}
function deal(obj){
	var r=confirm("请确认是否更改？");
	if (r==true)
	{
	    var id = obj.id.split(",");
		var deal;
		console.log(obj);
		if(id[1]=='0'){
			deal='已处理';
			id[1]='1';
		}else{
			deal='未处理';
			id[1]='0';
		}
		obj.innerHTML=deal;
		obj.id=id[0]+','+id[1];
		console.log(id[0]+','+id[1]);
		$.post("database/dealupdate.php", {
			id:id[0],
			deal:id[1]
		    }, function(data){
		    	console.log('data'+data);
		     }, 
		"json");
	}
}

function Delete(obj){
	var r=confirm("请确认是否删除？");
	var img_initdir = "/www/wwwroot/navi/pathimg/";
	var img_finaldir = "/www/wwwroot/navi/finalimg/";
	if (r==true)
	{
	    var id = obj.id.split("/");
	    console.log(id);
		$.post("database/delete.php", {
			time:id[0],
			name:id[1]
		    }, function(data){
		    	console.log('data'+data);
		     }, 
		"json");
	}
	admin_dot(1);
}
//点的信息
function pointInfo(point){
	var sContent ="1";
	var marker = new BMap.Marker(point);
	var infoWindow = new BMap.InfoWindow(sContent);  // 创建信息窗口对象
	map.centerAndZoom(point, 15);
	map.addOverlay(marker);
	marker.addEventListener("click", function(){          
	   this.openInfoWindow(infoWindow);
	   //图片加载完毕重绘infowindowl
	   document.getElementById('imgDemo').onload = function (){
		   infoWindow.redraw();   //防止在网速较慢，图片未加载时，生成的信息框高度比图片的总高度小，导致图片部分被隐藏
	   }
	});
}

function gcj02tobd09(lng, lat) {
    var z = Math.sqrt(lng * lng + lat * lat) + 0.00002 * Math.sin(lat * x_PI);
    var theta = Math.atan2(lat, lng) + 0.000003 * Math.cos(lng * x_PI);
    var bd_lng = z * Math.cos(theta) + 0.0065;
    var bd_lat = z * Math.sin(theta) + 0.006;
    return [bd_lng, bd_lat]
}
 
/**
 * WGS84转GCj02
 * @param lng
 * @param lat
 * @returns {*[]}
 */
function wgs84togcj02(lng, lat) {
    if (out_of_china(lng, lat)) {
        return [lng, lat]
    }
    else {
        var dlat = transformlat(lng - 105.0, lat - 35.0);
        var dlng = transformlng(lng - 105.0, lat - 35.0);
        var radlat = lat / 180.0 * PI;
        var magic = Math.sin(radlat);
        magic = 1 - ee * magic * magic;
        var sqrtmagic = Math.sqrt(magic);
        dlat = (dlat * 180.0) / ((a * (1 - ee)) / (magic * sqrtmagic) * PI);
        dlng = (dlng * 180.0) / (a / sqrtmagic * Math.cos(radlat) * PI);
        var mglat = lat + dlat;
        var mglng = lng + dlng;
        var gps = new Array();
        gps = gcj02tobd09(mglng, mglat);
        //return [mglng, mglat]
        return gps;
    }
}

function transformlat(lng, lat) {

    var ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + 0.1 * lng * lat + 0.2 * Math.sqrt(Math.abs(lng));

    ret += (20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) * 2.0 / 3.0;

    ret += (20.0 * Math.sin(lat * PI) + 40.0 * Math.sin(lat / 3.0 * PI)) * 2.0 / 3.0;

    ret += (160.0 * Math.sin(lat / 12.0 * PI) + 320 * Math.sin(lat * PI / 30.0)) * 2.0 / 3.0;

    return ret

}

function transformlng(lng, lat) {

    var ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + 0.1 * lng * lat + 0.1 * Math.sqrt(Math.abs(lng));

    ret += (20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) * 2.0 / 3.0;

    ret += (20.0 * Math.sin(lng * PI) + 40.0 * Math.sin(lng / 3.0 * PI)) * 2.0 / 3.0;

    ret += (150.0 * Math.sin(lng / 12.0 * PI) + 300.0 * Math.sin(lng / 30.0 * PI)) * 2.0 / 3.0;

    return ret

}

/**

 * 判断是否在国内，不在国内则不做偏移

 * @param lng

 * @param lat

 * @returns {boolean}

 */

function out_of_china(lng, lat) {

    return (lng < 72.004 || lng > 137.8347) || ((lat < 0.8293 || lat > 55.8271) || false);

}







