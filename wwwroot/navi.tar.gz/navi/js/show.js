dot_time=1;
dot_len=0;

  $(document).ready(function(){
    admin_dot(4);
  });
  function admin_dot(length){
     var click="readmore()";
     var con='';
    $.post("../database/showInfo.php", {
    	length:length
    }, function(data){
    	var p_length=$(".panel").length;
    	$("#readmore").remove();
    	d_len=data.length;
    	r_length=data[d_len-1]["count(*)"];
       if(r_length<4&&dot_time==1)
       {
         length=r_length;
       }else if(dot_time==1){
         length=4;
       }else{
         if(dot_len>r_length){
           length=r_length;
         }else{
           length=dot_len;
         }
       }
       dot_len=length+4;	
       dot_time++;
      for (var i=p_length;i<length;i++)
      {
          $("#data-show").append(data[i][0]);
      }
      if(r_length!=length){
          $("#data-show").append("<button id='readmore' onclick="+click+">阅读更多</button>");
      }
     }, "json");

   }
   function readmore(){
   	 setTimeout(admin_dot(dot_len),1000);
   }



function dot_info(arr,id){
	var gps = gpsSplit(arr);
	var myGeo = new BMap.Geocoder();
	// 根据坐标得到地址描述    
	myGeo.getLocation(new BMap.Point(gps[0], gps[1]), function(result){      
	    if (result){      
	    	jQuery.post("database/getInfo.php", {
		    }, function(data){
				addr_set(id,result.address);
		     }, "json");
	    }      
	});
}
function gpsSplit(arr){
 	arr = arr.split(",");
	for(var i=0;i<arr.length;i++){
		arr[i] = parseFloat(arr[i],15);
	}
 	return arr;
}
	
function addr_set(id,addr){
	$.post("database/updateInfo.php", {
		id:id,
		addr:addr
	    }, function(data){
	    	console.log('data'+data);
	     }, 
	"json");
}

