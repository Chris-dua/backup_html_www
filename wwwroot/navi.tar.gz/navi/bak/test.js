var map;//map
var start,end,driving;
var endPoint;
//地图初始化
function map_init(){
	map = new BMap.Map("navmap");
	var point = new BMap.Point(116.404, 39.915);
	var navigationControl = new BMap.NavigationControl({
	    // 靠左上角位置
	    anchor: BMAP_ANCHOR_TOP_LEFT,
	    // LARGE类型
	    type: BMAP_NAVIGATION_CONTROL_LARGE,
	    // 启用显示定位
	    enableGeolocation: true
	});
	// 创建点坐标  
	map.centerAndZoom(point, 15);
	map.enableBizAuthLogo(); //开启
	map.enableScrollWheelZoom(true); 

}

//自我定位
function MyPlace(f){
	var geolocation = new BMap.Geolocation();
	// 开启SDK辅助定位
	geolocation.enableSDKLocation();
	geolocation.getCurrentPosition(function(r){
		if(this.getStatus() == BMAP_STATUS_SUCCESS){
			//var mk = new BMap.Marker(r.point);
			//map.addOverlay(mk);
			//map.panTo(r.point);
			//alert('您的位置：'+r.point.lng+','+r.point.lat);
			Navi(r.point.lat,r.point.lng,0);
		}
		else {
			alert('failed'+this.getStatus());
		}        
	});
	if(f==1){
		Navi(r.point.lat,r.point.lng,0)
	}
}

//导航
function Navi(L,G,f){
	if(f===0){
		driving = new BMap.DrivingRoute(map, { 
	    	renderOptions: { 
	        map: map, 
	        autoViewport: true 
		} 
		});
		start = new BMap.Point(G, L);
		end = endPoint;
		driving.search(start, end);
	}
}

//地图定点
function map_setpoint(x,y){
	// 创建地图实例  
    var	ggPoint = new BMap.Point(x,y);
    map.centerAndZoom(ggPoint, 15);
    map.addControl(new BMap.NavigationControl());
    
    //坐标转换完之后的回调函数
    translateCallback = function (data){
      if(data.status === 0) {
      	endPoint =data.points[0];
        pointInfo(data.points[0]);
        map.setCenter(data.points[0]);
        MyPlace(0);
        console.log(typeof(data.points[0]));
      }
    }

    setTimeout(function(){
        var convertor = new BMap.Convertor();
        var pointArr = [];
        pointArr.push(ggPoint);
        convertor.translate(pointArr, 1, 5, translateCallback)
    }, 1000);
}

//点的信息
function pointInfo(point){
	var sContent ="我太帅";
	var marker = new BMap.Marker(point);
	var infoWindow = new BMap.InfoWindow(sContent);  // 创建信息窗口对象
	map.centerAndZoom(point, 15);
	map.addOverlay(marker);
	marker.addEventListener("click", function(){          
	   this.openInfoWindow(infoWindow);
	   //图片加载完毕重绘infowindow
	   document.getElementById('imgDemo').onload = function (){
		   infoWindow.redraw();   //防止在网速较慢，图片未加载时，生成的信息框高度比图片的总高度小，导致图片部分被隐藏
	   }
	});
}

//将图片转化为base64
function getBase64Image(image,ext){
	//var canvas = document.createElement("canvas");
	var canvas = document.getElementById("canvas");
	var L = new Array();
	var G = new Array();
	
	image.width = Number(400),    //压缩后图片的宽度，这里设置为缩小一半
    image.height = Number(200), 
    
	canvas.width = image.width;
	canvas.height = image.height;
	var context = canvas.getContext("2d");
	//context.drawImage(image,0,0,image.width,image.height);
	// 这里是不支持跨域的
	var base64 = canvas.toDataURL("image/"+ext);
	console.log(base64);
	EXIF.getData(image, function() {
        L = parseFloat(CalGps(arrGet(image,L,"GPSLatitude")),10);
        G = parseFloat(CalGps(arrGet(image,G,"GPSLongitude")),10);
    	console.log(L+" "+G);
    	//endPoint = new BMap.Point(G,L);
        map_setpoint(G,L);
    });
}

//获得图片的地址的初始化函数
function getImageDot(){
	var imageSrc = "img/test.jpg";
	var image = new Image();
	image.src = imageSrc;
	var ext = imageSrc.substring(imageSrc.lastIndexOf(".")+1);
	getBase64Image(image,ext);
}

//获得图片的exif信息
function arrGet(obj,arr,str){
	for(var i = 0;i<3;i++){
		arr[i] = EXIF.getTag(obj, str)[i].numerator;
	}
	return arr;
}

//计算gps
function CalGps(arr){
	//arr = JSON.stringify(arr).split(",");
	//arr[0] = arr[0].replace(/\[|]/g,"");
	for(var i = 0;i<arr.length;i++){
		arr[i] = parseInt(arr[i], 10)
	}
	arr = (arr[0] + arr[1]/60 + arr[2]/3600).toFixed(15);
	return arr;
}
	
function $(element){
    return document.getElementById(element);
}
