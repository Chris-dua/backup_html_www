<?php
//跨域问题
  header("Access-Control-Allow-Origin:*");
  header('Access-Control-Allow-Methods:POST');
  header('Access-Control-Allow-Headers:x-requested-with, content-type');
echo'
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />

	<title>路面检测</title>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/default.css?v=1.1">
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://api.map.baidu.com/api?v=3.0&ak=buKcGnfV1AdGfOy458lGe9oF9iifwfh4"></script>
	<script type="text/javascript" src="js/exif.js"></script>
	<script src="test.js?v=0.497"></script>
</head>

<body>

	<nav class="navbar navbar-fixed-top">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="master.php">路面检测</a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a class="tag" href="master.php">首页</a></li>
	        <li><a class="tag" href="dataShow.php">数据查看</a></li>
	  		</ul>
			<form class="navbar-form navbar-right">
				<input type="text" class="form-control" placeholder="Search...">
			</form>
	  	</div>
		</div>
	</nav>
	<div class="container">
		<div class="inner-container">
			<div class="row">
		    <div class="col-sm-9 masterbar">
				<div class="panel panel-primary">
					<div class="post-tag">
						<span class="post-title label label-info">
							<a class="tag" href="tectalk.html" style="color:#fff">地图</a>
						</span>
					  <h2 class="post-title panel-title" style="margin-left:1%"><a href="#" style="text-decoration:none;">定位地图</a></h2>
					</div>
					<div class="panel-body">
						<div class="col-sm-8 post" id = "navmap">
						
						</div>
						<button id="drv" onClick="MyPlace(1)">navi</button>
						<button id="start" onClick="Navi(0,0,1)">start</button>

					</div>
				</div>
				<div class="panel panel-primary">
					<div class="post-tag">
						<span class="post-title label label-info">
							<a class="tag" href="tectalk.html" style="color:#fff">地图</a>
						</span>
					  <h2 class="post-title panel-title" style="margin-left:1%"><a href="#" style="text-decoration:none;">点图</a></h2>
					</div>
					<div class="panel-body">
						<div class="col-sm-8 navimg" >
								<canvas id = "canvas"></canvas>
						</div>
					</div>
				</div>
		    </div>
				<div class="col-sm-3 secbar">
					<div class="sidebar">
						<div class="side-tag">					
						<div class="panel-group" id="accordion">
					        <div class="panel panel-default">
					                <div class="panel-heading">
					                        <h4 class="panel-title">
				                                <a data-toggle="collapse" data-parent="#accordion"
				                                href="#collapseOne">
				                                视频预览
				                                </a>
					                        </h4>
					                </div>
									<div id="collapseOne" class="panel-collapse collapse in">
										<div class="panel-body">
								
										</div>
									</div>
							</div>
						</div>
						</div>
						<div class="side-doc-date">
							<div class="panel-group" id="accordion">
						        <div class="panel panel-default">
						                <div class="panel-heading">
						                        <h4 class="panel-title">
						                                <a data-toggle="collapse" data-parent="#accordion"
						                                href="#collapseOne">
						                                登陆
						                                </a>
						                        </h4>
						                </div>
						                <div id="collapseOne" class="panel-collapse collapse in">
						                        <div class="panel-body">
						                        </div>
						                </div>
						        </div>
					        </div>
						</div>
						<div class="side-friends-href">
						    <div class="panel-group" id="accordion">
						        <div class="panel panel-default">
					                <div class="panel-heading">
				                        <h4 class="panel-title">
				                                <a data-toggle="collapse" data-parent="#accordion"
				                                href="#collapseTwo">
				                                操作信息
				                                </a>
				                        </h4>
					                </div>
					                <div id="collapseOne" class="panel-collapse collapse in">
				                        <div class="panel-body">
											<fieldset class="operate">
										        <div id="opinfo" class="opinfo"></div>
									    	</fieldset>
				                        </div>
					                </div>
						        </div>
						     </div>
						</div>
			      <hr class="hidden-sm hidden-md hidden-lg">
					</div>
		    </div>
		  </div>
		</div>
	</div>
	<div class="jumbotron text-center" style="margin-bottom:0">
	  <p>深水无声</p>
	</div>
	<footer class="footer" style="background-color:#000;color:#fff">
		<p style="margin-bottom:0px">&copy; 2019 ljy, Inc.</p>
	</footer>
	<script>
		map_init();

		if(location.href.indexOf("#")==-1){
		　　//在当前页面地址加入"#"，使下次不再进入此判断
		    location.href=location.href+"#";
		    location.reload();
		}
		getImageDot();
	</script>
	
	
</body>

</html>';
?>