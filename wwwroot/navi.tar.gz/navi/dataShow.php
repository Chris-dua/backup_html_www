
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
	<title>路面检测</title>
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/default.css?v=1.26">
	<script src="https://cdn.staticfile.org/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://api.map.baidu.com/api?v=3.0&ak=wVM1mvPC16aVw83ZxF3z9kbuQsOxxZm8"></script>
	 <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
	<script type="text/javascript" src="js/exif.js"></script>
	<script src="js/show.js?v=0.208"></script>
	<script src="js/default.js?v=0.2014"></script>
	<script src="js/select.js?v=0.005"></script>
</head>
<body>
<script>

</script>
<?php 
echo '
	<nav class="navbar navbar-fixed-top">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="index.html">路面检测</a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a class="tag" href="index.html">首页</a></li>
	        <li><a class="tag" href="dataShow.php">数据查看</a></li>
	  		</ul>
			<form class="navbar-form navbar-right">
				<input type="text" class="form-control" placeholder="Search...">
			</form>
	  	</div>
		</div>
	</nav>
	<div class="container">
		<div class="inner-container">
			<div class="row" style = "width:100%;height:1000px;overflow: auto">
				<div id="select-info">
					<select id="tag-info" name="cars">
					</select>
					<select id="deal-info" name="cars">
						<option>default</option>
					</select>
					<select id="time-info" name="cars">
						<option>default</option>
					</select>
					<button onclick="getAll()">筛选</button>
					<button><a href="database/GetImgName.php">数据更新</a></button>

				</div>
		<div id="data-show">
		
		</div>
		  </div>
		</div>
	</div>
	<footer class="footer" style="background-color:#000;color:#fff">
		<p style="margin-bottom:0px">&copy; 2019 ljy, Inc.</p>
	</footer>
	<script>
		
  
	</script>
	
	
</body>

</html>
';
?>