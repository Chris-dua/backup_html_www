var map;//map
var start,end,driving;
var endPoint;
var point_init;

function startNavi(obj){
	var img_pos = obj.id.split(",");
	var img_L =  parseFloat(img_pos[0],10);
	var img_G =  parseFloat(img_pos[1],10);
	end = new BMap.Point(img_G,img_L);
	//map.clearOverlays(); 
	//getImageDot();
	MyPlace(1);
}
//自我定位
function MyPlace(f){
	var geolocation = new BMap.Geolocation();
	point_init = new Array();
	// 开启SDK辅助定位
	geolocation.enableSDKLocation();
	geolocation.getCurrentPosition(function(r){
		if((this.getStatus() == BMAP_STATUS_SUCCESS)&&(f===0)){
			point_init[0] = r.point.lng;
			point_init[1] = r.point.lat;
		}
		if(f==1)
		{
			Navi(r.point.lat,r.point.lng,0);
		}        
	});
	return point_init;
	

}
//地图初始化
function map_init(){
	map = new BMap.Map("navmap");
	var point = MyPlace(0);
	point = new BMap.Point(point[0],point[1]);
	map.centerAndZoom(point, 15);
	map.enableScrollWheelZoom(true); 
}
//导航
function Navi(L,G,f){

	if(f===0){
		driving = new BMap.DrivingRoute(map, { 
	    	renderOptions: { 
	        map: map, 
	        autoViewport: true 
		} 
		});
		driving.clearResults();
		start = new BMap.Point(G, L);
		
		driving.search(start, end);
	}
}

//地图定点
function map_setpoint(x,y){
	// 创建地图实例  
    var	ggPoint = new BMap.Point(x,y);
    map.centerAndZoom(ggPoint, 15);
    
    //坐标转换完之后的回调函数
    translateCallback = function (data){
      if(data.status === 0) {
      	endPoint =data.points[0];
        pointInfo(data.points[0]);
        map.setCenter(data.points[0]);
        

      }
    }

    setTimeout(function(){
        var convertor = new BMap.Convertor();
        var pointArr = [];
        pointArr.push(ggPoint);
        convertor.translate(pointArr, 1, 5, translateCallback)
    }, 1000);
}

//点的信息
function pointInfo(point){
	var sContent ="我太帅"+"<button id='"+point.lat+","+point.lng+"' onClick='startNavi(this)'>导航</button>";
	var marker = new BMap.Marker(point);
	var infoWindow = new BMap.InfoWindow(sContent);  // 创建信息窗口对象
	map.centerAndZoom(point, 15);
	map.addOverlay(marker);
	marker.addEventListener("click", function(){          
	   this.openInfoWindow(infoWindow);
	   //图片加载完毕重绘infowindowl
	   document.getElementById('imgDemo').onload = function (){
		   infoWindow.redraw();   //防止在网速较慢，图片未加载时，生成的信息框高度比图片的总高度小，导致图片部分被隐藏
	   }
	});
}


//获得图片的地址的初始化函数
function getImageDot(){
	var imageSrc = new Array("","img/test.jpg","img/test1.jpg","img/test2.jpg","");
	
	for(var i=0;i<imageSrc.length;i++){
		var image = new Image();
		image.src = imageSrc[i];
		var ext = imageSrc[i].substring(imageSrc[i].lastIndexOf(".")+1);
		getBase64Image(image,ext);
	}
}

//将图片转化为base64
function getBase64Image(image,ext){
	var canvas = document.createElement("canvas");
	var L = new Array();
	var G = new Array();
	
	image.width = Number(400),    //压缩后图片的宽度，这里设置为缩小一半
    image.height = Number(200), 
    
	canvas.width = image.width;
	canvas.height = image.height;
	var context = canvas.getContext("2d");
	//context.drawImage(image,0,0,image.width,image.height);
	// 这里是不支持跨域的
	var base64 = canvas.toDataURL("image/"+ext);
	EXIF.getData(image, function() {
        L = parseFloat(CalGps(arrGet(image,L,"GPSLatitude")),10);
        G = parseFloat(CalGps(arrGet(image,G,"GPSLongitude")),10);
    	//endPoint = new BMap.Point(G,L);
        map_setpoint(G,L);
    });
}

//获得图片的exif信息
function arrGet(obj,arr,str){
	for(var i = 0;i<3;i++){
		arr[i] = EXIF.getTag(obj, str)[i].numerator;
	}
	return arr;
}

//计算gps
function CalGps(arr){
	//arr = JSON.stringify(arr).split(",");
	//arr[0] = arr[0].replace(/\[|]/g,"");
	for(var i = 0;i<arr.length;i++){
		arr[i] = parseInt(arr[i], 10)
	}
	arr = (arr[0] + arr[1]/60 + arr[2]/3600).toFixed(15);
	return arr;
}
	
function $(element){
    return document.getElementById(element);
}
var imgData = new Array();
function getimginfo(){
	
	 jQuery.post("database/getInfo.php", {
    }, function(data){
		imgData = data;
		console.log(imgData);
     }, "json");
     return imgData;
}
